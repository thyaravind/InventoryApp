create procedure spResetWarehouses
as
BEGIN

drop table if exists warehouses
create table warehouses 
(WarehouseID int NOT NULL IDENTITY PRIMARY KEY,
WarehouseName varchar(50) NOT NULL,
RegionID int,
WarehouseAddress text Default 'NA',
)
end
go

