
create procedure spResetProducts
as
BEGIN

drop table if exists products
create table products 
(ProductID int NOT NULL IDENTITY PRIMARY KEY,
ProductName varchar(50) NOT NULL,
CollectionID int,
ProductDesc text Default 'NA',
SKU varchar(10) UNIQUE,
Price int
)
end
go

